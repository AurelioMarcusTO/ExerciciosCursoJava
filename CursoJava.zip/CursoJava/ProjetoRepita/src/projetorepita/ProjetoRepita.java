
package projetorepita;

import javax.swing.JOptionPane;

public class ProjetoRepita {

    public static void main(String[] args) {
     
     int n, s = 0, tot = 0, par = 0, impar = 0, maior = 0, m = 0;   
     do {   
      n = Integer.parseInt(JOptionPane.showInputDialog(null, 
              "<html>Digite um número:<br> <em>(valor 0 interrompe)</em></html>"));
      s += n;
      tot += 1;
      if (n % 2 == 0){
          par += 1;
      } else{
          impar += 1;
      }
      if (n > 100){
          maior += 1;
      }
      m = s/tot;
     } while (n != 0);
      JOptionPane.showMessageDialog(null, "<html>Resultado final: <hr>" + 
              "<br>Somatória vale: " + s + 
              "<br>O total de numeros digitados foi: " + tot +
              "<br>O total de numeros pares foi: " + par +
              "<br>O total de numeros impares foi: " + impar +
              "<br>Numeros maiores que 100: " + maior +
              "<br>A média entre os valores foi: " + m +
              "</html>");
        
    }
    
}
