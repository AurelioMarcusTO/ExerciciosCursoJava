
package testefuncao03;

public class TesteFuncao03 {

    public static void main(String[] args) {
        System.out.println("Vai começar a contagem: ");
        System.out.println(Operacoes.contador(1, 5));
    }
    
}
