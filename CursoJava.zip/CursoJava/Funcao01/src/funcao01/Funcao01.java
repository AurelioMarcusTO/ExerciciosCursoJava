
package funcao01;

public class Funcao01 {

    public static void main(String[] args) {
        
        Fatorial f = new Fatorial();
        f.setValor(5);
        System.out.print(f.getFormula());
        System.out.println(f.getFatorial());
        
    }
    
}
