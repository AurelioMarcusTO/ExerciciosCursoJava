
package repeticaofor;

public class RepeticaoFor {

    public static void main(String[] args) {
        
        int i, j;
        
        for (i=0;i<=5;i++){
            System.out.println("i = " + i);
            for (j=0;j<=6;j+=2){
                System.out.println("j = " + j);
            }
        }
        
    }
    
}
