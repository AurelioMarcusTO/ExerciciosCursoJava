
package exerc1;


public class Exerc1 {

    private static int idade;
    
    public static void main(String[] args) {
            idade += 5;
            System.out.println("Sua idade é " + idade);
    }
    
}
