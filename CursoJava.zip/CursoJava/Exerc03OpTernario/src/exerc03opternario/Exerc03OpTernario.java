
package exerc03opternario;

public class Exerc03OpTernario {

    public static void main(String[] args) {
        int media = 6;
        System.out.println(media>=6?"Aprovado":"Reprovado");
    }
    
}
