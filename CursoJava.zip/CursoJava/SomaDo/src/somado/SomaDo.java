
package somado;

import java.util.Scanner;

public class SomaDo {

    public static void main(String[] args) {
        
      int n, s=0;
      String resp;
      Scanner teclado = new Scanner(System.in);
      
      do {
          System.out.print("Digite um numero: ");
          n = teclado.nextInt();
          s += n;
          System.out.print("Quer continuar ?");
          resp = teclado.next();
          
      } while (resp.equals("s"));
        System.out.println("A soma de todos os valores é "+ s);
        
    }
    
}
