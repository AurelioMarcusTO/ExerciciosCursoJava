
package horadosistema;

import java.util.Calendar;
import java.util.Date;

public class HoraDoSistema {

    public static void main(String[] args) {
        Calendar ano = Calendar.getInstance();
        Date relogio = new Date();
        System.out.println("A hora do sistema é:");
        System.out.println(relogio.toString());
        System.out.println(ano.get(Calendar.YEAR));
        
    }
    
}
