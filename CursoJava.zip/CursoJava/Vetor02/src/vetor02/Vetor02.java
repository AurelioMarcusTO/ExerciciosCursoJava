
package vetor02;

import java.util.Arrays;

public class Vetor02 {

    public static void main(String[] args) {
        
        int num[] = {3, 5, 1, 8, 4};
        int p = Arrays.binarySearch(num, 1);
        System.out.println("Encontrei o valor na posição "+ p);
        
        Arrays.sort(num);
        for (int valor: num){
            System.out.println(valor);
        }
        
    }
    
}
