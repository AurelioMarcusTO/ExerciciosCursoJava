
package contadorwhile;

public class ContadorWhile {

    public static void main(String[] args) {
        
        int c = 0;
        
        while (c <= 10) {
            c++;
            if (c == 2 || c == 4){
                continue;
            }
            if (c == 8){
                break;
            }
            System.out.println(c);
            
        }
        
        int i = 5;
        do {
            System.out.println(i);
            i--;
        } while(i>=0);
        
    }
    
}
